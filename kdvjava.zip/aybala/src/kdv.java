import java.util.Scanner;

public class kdv {
    public static void main(String[] args) {

        double tutar, kdvOran = 0.18;

        Scanner input = new Scanner(System.in);

        System.out.println("Ücret tutarını giriniz:  ");
        tutar = input.nextDouble();

        double kdvTutar = tutar * kdvOran;
        double kdvliTutar = tutar + kdvTutar;

        System.out.println("kdvsiz Tutar : " + tutar);
        System.out.println("kdv Oranı: " + kdvOran);
        System.out.println("KDV tutarı: " + kdvTutar);
        System.out.println("KDV'li tutar: " + kdvliTutar);
    }
}